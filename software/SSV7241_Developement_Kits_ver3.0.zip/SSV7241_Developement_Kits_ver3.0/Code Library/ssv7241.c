/******************************************************************************
 * Version 3.0 Formal Released
 * Relased by: mog.wu@icomm-semi.com
 * Date: 2015/09/23
 * Update:
 * 1. SSV7241 performance patch: Initial_Reg_Array()
 * 		- enhanced performance
 * 		- solved MISO leakage issue
 * 		- simplified version can be used if used requires to use Auto-ACK mode
 * 2. Update
 * 		- SSV7241_TxPacket()
 * 		- SSV7241_TxACKPacket()
 * 		- SSV7241_TxPacketWithoutAck()
 *		- SSV7241_PowerOn()
 *		- SSV7241_PowerOff()
 * 		- SSV7241_Enable3dBm()
 * 		- SSV7241_Enable0dBm()	
 * 3. New add
 * 		- SSV7241_Enable5dBm()
 * 		- SSV7241_Enable4dBm()
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "ssv7241.h"

/* default TX/RX Address and Address Width */
const uint8 TX_ADDRESS[TX_ADR_WIDTH]={0x67,0xE7,0xE7,0xE7,0xE7}; 
const uint8 RX_ADDRESS[RX_ADR_WIDTH]={0x67,0xE7,0xE7,0xE7,0xE7}; 

#define simplified 0

/* memo */
uint8 DYN_ACKOn = 0;
uint8 ACK_PAYOn = 0;

#if simplified 
uint8 Initial_Reg_Array[] = {
0x1F, 0x01, 0x00,
0x1B, 0x04, 0x10, 0xE1, 0xD3, 0x3D,
0x19, 0x04, 0x06, 0xAA, 0xA2, 0xDB,
0x1A, 0x04, 0x27, 0x61, 0x01, 0xF8,
0x1F, 0x01, 0x01,
0x18, 0x04, 0xBF, 0x94, 0x00, 0xDF,
0x19, 0x04, 0xBB, 0x48, 0x9A, 0xE8,
0x1B, 0x04, 0x76, 0x87, 0xCA, 0x01,
0x1F, 0x01, 0x02,
0x1B, 0x04, 0xA0, 0x00, 0x18, 0xA0,
0x1F, 0x01, 0x04,
0x18, 0x04, 0x01, 0x00, 0xF0, 0x00,
0x1F, 0x01, 0x05,
0x18, 0x04, 0x84, 0x03, 0x2A, 0x03,
0x19, 0x04, 0x90, 0xBF, 0x00, 0x00,
0x1A, 0x04, 0xA0, 0x0F, 0x00, 0x00,
0x1F, 0x01, 0x09,
0x19, 0x04, 0x98, 0x00, 0x03, 0x00,
0x1F, 0x01, 0x00
};
#else
uint8 Initial_Reg_Array[] = {
0x1F, 0x01, 0x00,
0x1B, 0x04, 0x10, 0xE1, 0xD3, 0x3D,
0x19, 0x04, 0x06, 0xAA, 0xA2, 0xDB,
0x1A, 0x04, 0x27, 0x61, 0x01, 0xF8,
0x1F, 0x01, 0x01,
0x18, 0x04, 0xBF, 0x94, 0x00, 0xDF,
0x19, 0x04, 0xBB, 0x48, 0x9A, 0xE8,
0x1B, 0x04, 0x76, 0x87, 0xCA, 0x01,
0x1F, 0x01, 0x02,
0x1B, 0x04, 0xA0, 0x00, 0x18, 0xA0,
0x1F, 0x01, 0x04,
0x18, 0x04, 0x01, 0x00, 0xF0, 0x00,
0x1F, 0x01, 0x05,
0x18, 0x04, 0x84, 0x03, 0x2A, 0x03,
0x19, 0x04, 0x90, 0xBF, 0x00, 0x00,
0x1A, 0x04, 0xA0, 0x0F, 0x00, 0x00,
0x1F ,0x01 ,0x08,
0x19 ,0x01 ,0x10,
0x18 ,0x04 ,0x07 ,0x02 ,0x04 ,0x00,
0x19 ,0x01 ,0xD8,
0x19 ,0x01 ,0xF8,
0x18 ,0x04 ,0xD1 ,0x01 ,0xF8 ,0x03,
0x19 ,0x01 ,0x9E,
0x19 ,0x01 ,0xBE,
0x18 ,0x04 ,0x00 ,0x0A ,0x08 ,0x00,
0x19 ,0x01 ,0xDE,
0x19 ,0x01 ,0xFE,
0x18 ,0x04 ,0xCE ,0xC1 ,0xFF ,0x03,
0x19 ,0x01 ,0x9F,
0x19 ,0x01 ,0xbF,
0x18 ,0x04 ,0x00 ,0x08 ,0x08 ,0x00,
0x19 ,0x01 ,0xDF,
0x19 ,0x01 ,0xFF,
0x18 ,0x04 ,0x1D ,0xEE ,0xEF ,0x00,
0x19 ,0x01 ,0x1E,
0x19 ,0x01 ,0x3E,
0x18 ,0x04 ,0x07 ,0x5B ,0x30 ,0x0A,
0x19 ,0x01 ,0x5E,
0x19 ,0x01 ,0x7E,
0x18 ,0x04 ,0x66 ,0xCC ,0xFC ,0x00,
0x19 ,0x01 ,0x1F,
0x19 ,0x01 ,0x3F,
0x18 ,0x04 ,0x01 ,0x0B ,0x50 ,0x0C,
0x19 ,0x01 ,0x5F,
0x19 ,0x01 ,0x7F,
0x19 ,0x01 ,0x25,
0x1F ,0x01 ,0x09,
0x18 ,0x04 ,0x00 ,0x00 ,0xFE ,0xFE,
0x19 ,0x04 ,0x98 ,0x00 ,0x03 ,0x00,
0x1F ,0x01 ,0x00
};
#endif

void SSV7241_InitSPI()
{
	//========================= USER DEFINE ==================
	GPIO_Open(GPIOD, GPIO_PMD_PMD1_OUTPUT, GPIO_PMD_PMD1_MASK); //CLK
	GPIO_Open(GPIOD, GPIO_PMD_PMD2_INPUT, GPIO_PMD_PMD2_MASK); //MISO
	GPIO_Open(GPIOD, GPIO_PMD_PMD0_OUTPUT, GPIO_PMD_PMD0_MASK);  //SCN 
	GPIO_Open(GPIOD, GPIO_PMD_PMD3_OUTPUT, GPIO_PMD_PMD3_MASK); //MOSI
	GPIO_SetBit(GPIOD, 0);
	GPIO_ClrBit(GPIOD, 1);
	GPIO_ClrBit(GPIOD, 3);
	
	GPIO_EnablePullup(GPIOD, 2);
	//========================= USER DEFINE ==================
}

void SSV7241_Init()
{
	
	uint8 ret = 0;
	uint8 value; 
	
	/* Initial Register */
		uint32 i = 0, j = 0, k = 0;
		uint8 data[4];		
		uint32 array_length = sizeof(Initial_Reg_Array);
		
		while(i < array_length)
		{
			if(Initial_Reg_Array[i+1] == 0x01)
			{
				SSV7241_Write_Reg( W_REG | Initial_Reg_Array[i], Initial_Reg_Array[i+2]);
				i += 3;
			}
			else
			{ k=Initial_Reg_Array[i+1];
				for(j = 0; j < k; j++)
				{
					data[j] = Initial_Reg_Array[i+2+j];
				}

				SSV7241_Write_Buf( W_REG | Initial_Reg_Array[i], data, Initial_Reg_Array[i + 1]);
				i += 2+k;
			}
		}
	value = SSV7241_Read_Reg(CFG_TOP); 
	value | = (EN_CRC | CRC_2B);
	SSV7241_Write_Reg(W_REG | CFG_TOP, value);
	SSV7241_Write_Reg(W_REG | EN_AA,0x00);    
  SSV7241_Write_Reg(W_REG | EN_RXADDR,0x00);
  SSV7241_Write_Reg(W_REG | RF_CH,77);	
	SSV7241_Write_Reg(W_REG | RX_PW_P0,1);
	
}

uint8 SSV7241_CheckID(void)
{
	uint8 ret = 0;
	uint8 data[4];
	
	/* When power off, Chip ID can be read */
	SSV7241_PowerOff();
	/* When RSSI disable, Chip ID can be read */
	SSV7241_DisableRSSI();
	
	SSV7241_Read_Buf(0x18, data, 4); 
	
	if(data[0] == 0x41 && data[1] == 0x72)
		ret = 1;

	return ret;
}

void SSV7241_Write_Reg(uint8 reg,uint8 value)
{
	CS_Low;	   
  	
	SPI0_communication(reg);
	SPI0_communication(value);
	
	CS_High;   
}

uint8 SSV7241_Read_Reg(uint8 reg)
{
 	uint8 value;

	CS_Low;	    
  	
	SPI0_communication(reg);
	
	value = SPI0_communication(NOP);
	
	CS_High; 

	return value;
}

void SSV7241_Read_Buf(uint8 reg,uint8 *pBuf,uint8 len)
{
	uint8 i;
	
	CS_Low;      
  	
	SPI0_communication(reg);  	   
 	
	for(i = 0; i < len; i++)
		pBuf[i]=SPI0_communication(NOP);
	
	CS_High; 
}

void SSV7241_Write_Buf(uint8 reg, uint8 *pBuf, uint8 len)
{
	uint8 i;
	
	CS_Low;
	
	SPI0_communication(reg);
	
  for(i = 0; i < len; i++)
		SPI0_communication(*pBuf++); 
	
	CS_High;	 
}

uint8 SSV7241_isRXReady(void)
{
	uint8 ret = 0, state;
	
	state = SSV7241_Read_Reg(STATUS);  
	if(state & RX_DR)
		ret = 1;
	
	return ret;
}

uint8 SSV7241_isTXFULL(void)
{
	uint8 ret = 0, state;
		
	state = SSV7241_Read_Reg(STATUS_FIFO);
	if(state & TX_FULL)
		ret = 1;
	return ret;
}

uint8 SSV7241_isRXEMPTY(void)
{
	uint8 ret = 0, state;
	
	state = SSV7241_Read_Reg(STATUS_FIFO);
	if(state & RX_EMPTY)
		ret = 1;
	return ret;	
}

void SSV7241_ClearRX_DR(void)
{
	uint8 state;
		
	state = SSV7241_Read_Reg(STATUS);
	state | = RX_DR;
	SSV7241_Write_Reg(W_REG | STATUS, state);
}

void SSV7241_ClearTX_DS(void)
{
	uint8 state;
	
	state = SSV7241_Read_Reg(STATUS); 
	state | = TX_DS;	
	SSV7241_Write_Reg(W_REG | STATUS, state); 
	
}

void SSV7241_ClearMAX_RT(void)
{
	uint8 state;
	
	state = SSV7241_Read_Reg(STATUS); 
	state | = MAX_RT;	
	SSV7241_Write_Reg(W_REG | STATUS, state);
}

void SSV7241_FlushRX(void)
{
	SSV7241_Write_Reg(FLUSH_RX, NOP);
}

void SSV7241_FlushTX(void)
{
	SSV7241_Write_Reg(FLUSH_TX, NOP);
}

uint8 SSV7241_RxPacket(uint8 *rxbuf)
{
	uint8 ret = 0, len = 0;
	
	//Check and Receive Data
	if(SSV7241_isRXReady())
	{
		len = SSV7241_Read_Reg(R_RX_PL_WID);
		if(len==0)
			SSV7241_FlushRX();
		else
			SSV7241_Read_Buf(R_RX_PLOAD, rxbuf, len); 
	
		//Clear RX_DR status
		SSV7241_ClearRX_DR();
		
		ret = 1;
	}
	
	return ret;
}

void SSV7241_TxPacket(uint8 *txbuf, uint8 len)
{ 
	//Check Queue is full or not and Send packet
	if(!SSV7241_isTXFULL())
	{	
		if(!DYN_ACKOn)
			SSV7241_Write_Buf(W_TX_PLOAD, txbuf, len);
		else
			SSV7241_Write_Buf(W_TX_PLOAD_NOACK, txbuf, len);
		
		CE_High;
    //CE High till TX_DS=1 or IRQ=0	
	}
}

//Notice, SSV7241_TxACKPacket() is used only at PRX mode with EN_AA=1
//this function sholud be used before RX recevied Packet
//to let ACK packet be prepared 
void SSV7241_TxACKPacket(uint8 *txbuf, uint8 len)
{ 
	//Check Queue is full or not and Send packet
	if(!SSV7241_isTXFULL())
	{	
		SSV7241_Write_Buf(W_ACK_PLOAD, txbuf, len);
	}
}

//Notice, SSV7241_TxPacketWithoutAck() is only can ve used under EN_AA=1
//Only for Auto-ACK mode condition
void SSV7241_TxPacketWithoutAck(uint8 *txbuf, uint8 len)
{ 
	//Check Queue is full or not and Send packet
	if(!SSV7241_isTXFULL())
	{
  	
		if(DYN_ACKOn)
			SSV7241_Write_Buf(W_TX_PLOAD, txbuf, len);
		else
			SSV7241_Write_Buf(W_TX_PLOAD_NOACK, txbuf, len);
 	
	  CE_High;
    //CE High till TX_DS=1 or IRQ=0			
	}
}	

void SSV7241_RX_Mode(void)
{
	  	     
  uint8 value;
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value |= RX_ON;	
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 	
	CE_High;
}

void SSV7241_TX_Mode(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value &= ~RX_ON;
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 
	
}

void SSV7241_PowerOn(void)
{
	uint8 value;
	uint8 data[4];

	//restore RF internal LDO output voltage to no	normal value
	//Notice:
	//this restore step is only if user had refine the internal LDO to lower value when Power Off 
	//otherwise user can skip this restore step
	data[0] = 0x06;
	data[1] = 0xAA;
	data[2] = 0xA2;
	data[3] = 0xDB;
	SSV7241_Write_Buf( W_REG | 0x19, data, 4);
	//after resotre RF internal LDO output, please add 100us delay after LDO output stable
	SYS_Delay_100us();
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value |= PWR_ON;	
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 
	

}

void SSV7241_PowerOff(void)
{
	uint8 value;
	uint8 data[4];
	
	value = SSV7241_Read_Reg(CFG_TOP); 
	value &= ~PWR_ON;
	SSV7241_Write_Reg(W_REG | CFG_TOP, value); 	
	
	//refine RF internal LDO output voltage to lower value
	//Notice:
	//this refine step is only required for power saving purposed otherwise user can skip this refine step
	data[0] = 0x06;
	data[1] = 0xAA;
	data[2] = 0x02;
	data[3] = 0x00;
	SSV7241_Write_Buf( W_REG | 0x19, data, 4);
}

void SSV7241_Feature_DYN_ACK(uint8 Dyn_ack)
{
	uint8 value;
	
	/* Dynamic Ack Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Dyn_ack)
	{
		value |= EN_DYN_ACK;
		DYN_ACKOn = 1;
	}
	else
	{
		value &= ~EN_DYN_ACK;
		DYN_ACKOn = 0;
	}
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_Feature_DPL(uint8 Dpl)
{
	uint8 value;
	
	/* Dynamic Ack Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Dpl)
		value |= EN_DPL;
	else
		value &= ~EN_DPL;
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_Feature_ACK_PAY(uint8 Ack_pay)
{
	uint8 value;
	
	/* Ack Payload Setting */
	value = SSV7241_Read_Reg(FEATURE);
	
	if(Ack_pay)
	{
		value |= EN_ACK_PAY;
		ACK_PAYOn = 1;
	}
	else
	{
		value &= ~EN_ACK_PAY;
		ACK_PAYOn = 0;
	}
	
	SSV7241_Write_Reg(W_REG | FEATURE, value); 	
}

void SSV7241_EnableRSSI(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(RSSI);
	value |= EN_RSSI;
	
	SSV7241_Write_Reg(W_REG | RSSI, value); 	
}

void SSV7241_DisableRSSI(void)
{
	uint8 value;
	
	value = SSV7241_Read_Reg(RSSI);
	value &= ~EN_RSSI;
	
	SSV7241_Write_Reg(W_REG | RSSI, value); 	
}

void SSV7241_SetChannel(uint8 channel)
{
	
	SSV7241_Write_Reg(W_REG | RF_CH, channel); 
	
}

void SSV7241_Enable5dBm(void)
{
	uint8 data[4];
// Refine RF TX power
// Register 0x06, SETUP_RF
// RF_PWR[1:0]=	2'b11 +6dBm
//							2'b10	5dBm
//							2'b01	-6dBm
//							2'b00 -12dBm
	data[0] = 0x3F;
	data[1] = 0x1D;
	data[2] = 0x01;
	data[3] = 0xDF;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x01);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

void SSV7241_Enable4dBm(void)
{
	uint8 data[4];
// Refine RF TX power
// Register 0x06, SETUP_RF
// RF_PWR[1:0]=	2'b11 +6dBm
//							2'b10	4dBm
//							2'b01	-6dBm
//							2'b00 -12dBm
	data[0] = 0x3F;
	data[1] = 0x1B;
	data[2] = 0x01;
	data[3] = 0xDF;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x01);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

void SSV7241_Enable3dBm(void)
{
	uint8 data[4];
// Refine RF TX power
// Register 0x06, SETUP_RF
// RF_PWR[1:0]=	2'b11 +6dBm
//							2'b10	3dBm
//							2'b01	-6dBm
//							2'b00 -12dBm
	data[0] = 0x3F;
	data[1] = 0x19;
	data[2] = 0x01;
	data[3] = 0xDF;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x01);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

void SSV7241_Enable0dBm(void)
{
	uint8 data[4];
// Refine RF TX power
// Register 0x06, SETUP_RF
// RF_PWR[1:0]=	2'b11 +6dBm
//							2'b10	0dBm
//							2'b01	-6dBm
//							2'b00 -12dBm
	data[0] = 0x3F;
	data[1] = 0x17;
	data[2] = 0x01;
	data[3] = 0xDF;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x01);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

void SSV7241_EnableRSSIHoldPacketMode(void)
{
	uint8 data[4];
	/* refine RF mode*/
	data[0] = 0x00;
	data[1] = 0x00;
	data[2] = 0xFB;
	data[3] = 0xF6;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x09);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

void SSV7241_DisableRSSIHoldPacketMode(void)
{
	uint8 data[4];
	/* refine RF mode*/
	data[0] = 0x00;
	data[1] = 0x00;
	data[2] = 0xFE;
	data[3] = 0xFE;
	SSV7241_Write_Reg( W_REG | 0x1F, 0x09);
	SSV7241_Write_Buf( W_REG | 0x18, data, 4);
	SSV7241_Write_Reg( W_REG | 0x1F, 0x00);
}

uint8 SPI0_communication(uint8 SPI_byte)
{
	uint8 SPI_count; // counter for SPI transaction
	
	//========================= USER DEFINE ==================
	// need to define MOSI, MISO, SCK signal
	
	for (SPI_count = 8; SPI_count > 0; SPI_count--) // single byte SPI loop
	{
		MOSI = SPI_byte & 0x80; // put current outgoing bit on MOSI
		SPI_byte = SPI_byte << 1; // shift next bit into MSB
		SCK = 0x01; // set SCK high
		SPI_byte |= MISO; // capture current bit on MISO
		SCK = 0x00; // set SCK low
	}
	
	//========================= USER DEFINE ==================

	return (SPI_byte);
} // END SPI_Transfer

