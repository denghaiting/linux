/******************************************************************************
 * @file     Smpl_Main.c
 * @brief    Nano1xx NUTINY-EVB_NANO130 LCD Demo code
 * @version  1.0.1
 * @date     31, September, 2015
 *
 * @note
 * Copyright (C) 2012-2014 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>
#include <string.h>
#include "ssv_types.h"
#include "ssv_reg.h"
#include "ssv7241.h"
#include "ssv_cfg.h"
#include "nuvoton\\nvt_lcd.h"
#include "ssv_reg_init_tbl.h"
#include "nano1xx.h"
#include "nano1xx_timer.h"
#include "nano1xx_assert.h"
#include "nano1xx_gpio.h"
uint32_t __IO u32Timer0Cnt=0, u32Timer1Cnt=0, u32Timer2Cnt=0, u32Timer3Cnt=0,r=0;
int volatile wwdt_cnt=0;
uint32_t u32CounterINT=0;
uint8_t volatile b8WDTINT=FALSE;
uint32	rx_cnt;

uint8	g_test_pat[TRX_PL_WID] = 
{
 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0x00
}; // Payload
void lp_tx(uint8 spi_tx, uint32 loops)
{
	uint8	txbuf[TRX_PL_WID]; 
	char	msg[32];
	uint32	i,j;
	uint32	tx_cnt;
	
	SPI_SET(spi_tx);
	SSV7241_TX_Mode();// TX mode
	SSV7241_Write_Reg(W_REG|REG_EN_AA,0x01);//enable Auto ACK
	SSV7241_Write_Reg(W_REG|REG_SETUP_RETR, 0x23);//set auto retransmit count and auto retransmit delay time
	SSV7241_Write_Reg(W_REG|REG_EN_RXADDR, 0x01);//enable RX Address
	SSV7241_PowerOn();// power on
	SYS_Delay(5000);// after power on, must delay 5ms
	memcpy(txbuf, g_test_pat, TRX_PL_WID);	
	while(1) 
	{
		tx_cnt = 0;
		for (i=0; i<loops; i++)
		{
			CE_High;
			SSV7241_FlushTX();// Flush FIFO must under CE_high
			CE_Low;
			SSV7241_TxPacket(txbuf, TRX_PL_WID);//transmit packet
			while(!SSV7241_isTXACKComplete());//whether transmit packet complete or no?
			CE_Low;
			SSV7241_ClearTX_DS();//clear TX_DS
			txbuf[31] = txbuf[31]++;		
			tx_cnt ++;
			sprintf(msg, "%d", tx_cnt);		
			LCD_Write(msg);
			for(j=0; j<8; j++)
			{
			SYS_Delay(US_1MS);
			}
		}
		txbuf[31] = 0x00;
		for(j=0; j<2000; j++)
		{
		SYS_Delay(US_1MS);
		} 
	}
}
bool lp_rx(uint8 spi_rx)
{
	uint8 rxbuf[TRX_PL_WID];
	char	msg[8];
	//uint32  i, n;

	SPI_SET(spi_rx);
	SSV7241_RX_Mode();// RX mode
	SSV7241_Write_Reg(W_REG|REG_EN_AA,0x01);//enable Auto ACK
	SSV7241_Write_Reg(W_REG|REG_EN_RXADDR, 1);// enable RX address
	SSV7241_Write_Reg(W_REG|REG_RX_PW_P0, TRX_PL_WID);//set RX Payload width 
	SSV7241_PowerOn();// power on
 	SYS_Delay(5000);// after power on, must delay 5ms
	memset(rxbuf, 0x00, TRX_PL_WID);
   
	TIMER_Init(TIMER0, 11, 2000000, TIMER_CTL_MODESEL_ONESHOT);//Timer0��ʼ��
	TIMER_EnableInt(TIMER0, TIMER_IER_TMRIE);
	//CE_High;
	while (1)
	{
		CE_High;
	  while(!SSV7241_RxPacket(rxbuf)); //whether RX receive packet or no?
		rx_cnt++;
		if(rx_cnt == 1)
		{		
				TIMER_Start(TIMER0);		  
		}
		sprintf(msg, "%d", rx_cnt);	
		LCD_Write(msg);	
	}
}
/**
  * @brief  Main routine. 
  * @param  None.
  * @return None.
  */
int32_t main(void)							   
{
	while(!ssv_hw_init());   
	while(!SSV7241_InitSPI(SPI_2));	
	// ======================= open SPI 0 ==========================
	SPI_SET(SPI_2);							  //SPI GPIO set
	while(SSV7241_CheckID() == 0);//check SSV7241 ID
	SSV7241_Init();               //SSV7241 initial
	LCD_Write("1P");
	// ======================= TX\RX mode ==========================
#if(LP_TX)                                                       //LP_TX=1: code for tx side, LP_TX=0: code for rx side
	lp_tx(SPI_2, TRX_LOOPS);			//TX mode
#else
	lp_rx(SPI_2);									//RX mode
#endif
}
